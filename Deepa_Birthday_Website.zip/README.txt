# Deepa Birthday Website ❤️

## What is included
A mobile-friendly romantic birthday countdown from Param to Deepa:
- Daily countdown from Aug 27 to Sep 6
- Memories: first long ride, Coffiness Coffee, walking
- Flower interactions
- Birthday letter
- Final birthday surprise
- No server/database required

## Free publishing
Use GitHub Pages:
1. Create a free GitHub account.
2. Create a new PUBLIC repository, e.g. `deepa-birthday`.
3. Upload `index.html`.
4. Repository → Settings → Pages.
5. Under Build and deployment, choose `Deploy from a branch`.
6. Select `main` and `/ (root)`, then Save.
7. GitHub will give you a free `github.io` link.
8. Open the link on your phone to test it.
9. Use any free QR-code generator to turn the link into a QR code.

## Important
The daily unlock is based on the visitor's device date. The page is designed for the August 27 → September 6 countdown in the same calendar year.
